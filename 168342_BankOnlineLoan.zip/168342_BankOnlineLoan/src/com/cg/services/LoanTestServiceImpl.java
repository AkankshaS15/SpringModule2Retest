package com.cg.services;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bean.Customer_Details;
import com.cg.dao.ILoanTestDAO;
import com.cg.dao.LoanTestDAOImpl;

@org.springframework.stereotype.Service
public class LoanTestServiceImpl implements ILoanTestService {
    @Autowired
    ILoanTestDAO dao=new LoanTestDAOImpl();
   
public ILoanTestDAO getDao() {
		return dao;
	}
	public void setDao(ILoanTestDAO dao) {
		this.dao = dao;
	}
	
@Override
public boolean testPAN(String Pan_Card_Number) {
	return dao.testPAN(Pan_Card_Number);
}
@Override
public Customer_Details getDetails(String Pan_Card_Number) {
	
	return dao.getDetails(Pan_Card_Number);
}
}

    