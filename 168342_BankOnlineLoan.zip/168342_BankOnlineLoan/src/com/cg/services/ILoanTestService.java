package com.cg.services;

import com.cg.bean.Customer_Details;

public interface ILoanTestService {
	boolean testPAN(String Pan_Card_Number);
	Customer_Details getDetails(String Pan_Card_Number);
}