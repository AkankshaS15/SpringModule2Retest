package com.cg.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.bean.Customer_Details;
import com.cg.services.ILoanTestService;
import com.cg.services.LoanTestServiceImpl;

//@org.springframework.stereotype.Controller
@Controller
public class LoanTestController {
	@Autowired
	ILoanTestService service=new LoanTestServiceImpl();
	
	public ILoanTestService getService() {
		return service;
	}
	public void setService(ILoanTestService service) {
		this.service = service;
	}
	@RequestMapping(value="/testPAN",method=RequestMethod.GET)
	public String  toDiplayTestPage(Model model) {
		Customer_Details cust=new Customer_Details();
	model.addAttribute("obj",cust);
	return "acceptpancard";
	
	}
	@RequestMapping(value="/testPANFirst",method=RequestMethod.POST)
	public String toGetIdPage(Model model,@ModelAttribute(value="customer")Customer_Details customer,BindingResult result) {
		if(result.hasErrors())return "redirect:/acceptpancard";
		System.out.println("hey..................."+customer.getPan_Card_Number());
			if(service.testPAN(customer.getPan_Card_Number())) {
			customer=service.getDetails(customer.getPan_Card_Number());
			model.addAttribute("Custo",customer);
			if(customer.getCibil_Score()>750)
			{
			//model.addAttribute("Custo",customer);
			return "Success";
			}
			}
			
			else
			return "Failure";
			return "Failure";
			

	}
}