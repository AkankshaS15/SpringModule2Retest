
package com.cg.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
public class Customer_Details {
@Id
@NotEmpty(message="PANCARDNUMBER is mandatory to enter to test your eligibility")
@Column(name="Pan_Card_Number")
private String pan_Card_Number;
@Column(name="Customer_Name")
private String customer_Name;
@Column(name="Email_Id")
private String email_Id;
@Column(name="Cibil_Score")
private int cibil_Score;
@Column(name="Mobile_Number")

private int mobile_Number;
@Pattern(regexp="^([A-Z] {5}+[0-9] {4}+[A-Z] {1}$",message="Please follow the format.EX.ABCDE1234Z")

public String getPan_Card_Number() {
	return pan_Card_Number;
}
public void setPan_Card_Number(String pan_Card_Number) {
	this.pan_Card_Number = pan_Card_Number;
}
public String getCustomer_Name() {
	return customer_Name;
}
public void setCustomer_Name(String customer_Name) {
	this.customer_Name = customer_Name;
}
public String getEmail_Id() {
	return email_Id;
}
public void setEmail_Id(String email_Id) {
	this.email_Id = email_Id;
}
public int getCibil_Score() {
	return cibil_Score;
}
public void setCibil_Score(int cibil_Score) {
	this.cibil_Score = cibil_Score;
}

public int getMobile_Number() {
	return mobile_Number;
}
public void setMobile_Number(int mobile_Number) {
	this.mobile_Number = mobile_Number;
}
public Customer_Details() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer_Details(String pan_Card_Number, String customer_Name, String email_Id, int cibil_Score,
		int mobile_Number) {
	super();
	this.pan_Card_Number = pan_Card_Number;
	this.customer_Name = customer_Name;
	this.email_Id = email_Id;
	this.cibil_Score = cibil_Score;
	this.mobile_Number = mobile_Number;
}
@Override
public String toString() {
	return "Customer_Details [pan_Card_Number=" + pan_Card_Number + ", customer_Name=" + customer_Name + ", email_Id="
			+ email_Id + ", cibil_Score=" + cibil_Score + ", mobile_Number=" + mobile_Number + "]";
}


}







