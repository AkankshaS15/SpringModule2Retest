package com.cg.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.cg.bean.Customer_Details;
@Repository
@Transactional
public class LoanTestDAOImpl implements ILoanTestDAO {
@PersistenceContext
EntityManager entityManager;
	public EntityManager getEntityManager() {
	return entityManager;}
public void setEntityManager(EntityManager entityManager) {
	this.entityManager = entityManager;
}
	@Override
	public boolean testPAN(String Pan_Card_Number) {
		if(entityManager.find(Customer_Details.class,Pan_Card_Number)!=null)
return true;
		return false;
	}
	@Override
	public Customer_Details getDetails(String Pan_Card_Number) {
		
		return entityManager.find(Customer_Details.class,Pan_Card_Number);
	}
}