package com.cg.dao;

import com.cg.bean.Customer_Details;

public interface ILoanTestDAO {
	boolean testPAN(String Pan_Card_Number);
	Customer_Details getDetails(String Pan_Card_Number);
}